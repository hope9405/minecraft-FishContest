package kr.hyun.fishcontest;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import kr.hyun.fishcontest.command.CommandFC;
import kr.hyun.fishcontest.listeners.PlayerFishEventListener;



public class FishContest extends JavaPlugin implements Listener{
	public static ScoreboardHandler sbHandler;
	public int missionFish = -1;
	public int missionScore = 0;
	public boolean debug=false;
	@Override
	public void onEnable(){
		getConfig().options().copyDefaults(true);
		
		sbHandler = new ScoreboardHandler(this);
		
		Bukkit.getScheduler().runTaskTimer(this, new Runnable(){
			@Override
			public void run(){
				sbHandler.updateTime();
			}
		}, 0, 20);
		getCommand("FC").setExecutor(new CommandFC(this));
		Bukkit.getPluginManager().registerEvents(new PlayerFishEventListener(this),this);
	}
	@Override
	public void onDisable(){
		sbHandler.saveFishConfig();
	}
}
