package kr.hyun.fishcontest;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;

import net.md_5.bungee.api.ChatColor;

public class ScoreboardHandler {
	private Scoreboard scoreboard;
	private Objective sideObj;
	private Objective listObj;
	private HashSet<String> set;
	int lMax =10;
	private int[] sList;
	private String[] nList;
	public boolean isStart = false;
	FishContest plugin;
	
	public void saveFishConfig(){
		plugin.getConfig().set("sideObj.score", sList);
		plugin.getConfig().set("sideObj.name", nList);
		plugin.saveConfig();
	}
	public void loadFishConfig(){
		sList = new int[lMax];
		nList = new String[lMax];
		set = new HashSet<>();
		ArrayList<Integer> sArr=null;
		ArrayList<String> nArr = null;
		
		sArr = (ArrayList<Integer>)plugin.getConfig().get("sideObj.score");
		nArr = (ArrayList<String>)plugin.getConfig().get("sideObj.name");
	
		if(sArr != null){
			for(int i = 0 ; i<sArr.size();i++){
				sList[i] = sArr.get(i);
			}
		}
		
		if(nArr != null){
			for(int i = 0 ; i< nArr.size();i++){
				if(nArr.get(i) == null) break;
				nList[i] = nArr.get(i);
				set.add(nList[i]);
			}
		}
	}
	public void chkSide(String name, int score){
		if(sList[lMax-1] < score){
			//���� �������� ����
			int i;
			if(set.contains(name)){
				i = lMax-1;
				for(; i >-1 ;i--){
					if(nList[i] != null && nList[i].equals(name)) break;
				}
				i--;
			}else{
				set.add(name); //�� �� �߰�
				set.remove(nList[lMax-1]); // �������� ����
				i = lMax-2;
			}
			for(; i>-1 ; i--){
				if(sList[i] < score){ // ���� ģ���� �� ũ��
					sList[i+1] = sList[i];
					nList[i+1] = nList[i];
				}else{
					sList[i+1] = score;
					nList[i+1] = name;
					break;
				}
			}
			if(i==-1){
				if(sList[0] < score){
					sList[0] = score;
					nList[0] = name;
				}
			}
			
			// �̶��� ���̵� �� ����
			newSideFish();
		}
	}
	public void sumScore(String name,int num){
		int sumS = plugin.getConfig().getInt("listObj."+name) + num;

		Score score = listObj.getScore(name);
		score.setScore(sumS);
		
		plugin.getConfig().set("listObj."+name,sumS);
		// ���̵�� üũ
		chkSide(name, sumS);
	}
	public void newSideFish(){
		sideObj.unregister();
		sideObj = scoreboard.registerNewObjective("sideFish", "dummy");			
		sideObj.setDisplaySlot(DisplaySlot.SIDEBAR);
		sideObj.setDisplayName(ChatColor.DARK_AQUA+getCurrentFormattedDate("hh:mm:ss"));
		for(int k = 0 ; k < lMax && k < set.size();k++){
			Score sre = sideObj.getScore(nList[k]);
			sre.setScore(sList[k]);
		}
	}
	public void newListFish(){
		listObj.unregister();
		listObj = scoreboard.registerNewObjective("listFish", "dummy");
		listObj.setDisplaySlot(DisplaySlot.PLAYER_LIST);
		listObj.setDisplayName("");
	}
	public ScoreboardHandler(FishContest _plugin){
		this.plugin = _plugin;
		loadFishConfig();
		
		scoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
		sideObj = scoreboard.getObjective("sideFish");
		if(sideObj == null){
			sideObj = scoreboard.registerNewObjective("sideFish", "dummy");			
			sideObj.setDisplaySlot(DisplaySlot.SIDEBAR);
			sideObj.setDisplayName(ChatColor.DARK_AQUA+getCurrentFormattedDate("hh:mm:ss"));
		}
		for(int k = 0 ; k < lMax && k < set.size();k++){
			Score sre = sideObj.getScore(nList[k]);
			sre.setScore(sList[k]);
		}

		listObj = scoreboard.getObjective("listFish");
		if(listObj == null){
			listObj = scoreboard.registerNewObjective("listFish", "dummy");
			listObj.setDisplaySlot(DisplaySlot.PLAYER_LIST);
			listObj.setDisplayName("");			
		}
		// ����� �������� ������ �ҷ���
		ConfigurationSection CFSec = plugin.getConfig().getConfigurationSection("listObj");
		if(CFSec != null){
			Set<String> setKey = CFSec.getKeys(false);
			
			for(Iterator<String> Iter = setKey.iterator();Iter.hasNext();){
				String name = Iter.next();
				Score sre = listObj.getScore(name);
				sre.setScore(CFSec.getInt(name));
			}
		}
	}
	public void sendPlayerScoreboard(Player p ){
		p.setScoreboard(scoreboard);
	}
	 public void updateTime() {
		 if(isStart){
			 sideObj.setDisplayName(ChatColor.DARK_AQUA + getCurrentFormattedDate("hh:mm:ss"));
		 }else{
			 sideObj.setDisplayName(ChatColor.DARK_AQUA + "��ȸ �غ���");
		 }
	 }
	 private String getCurrentFormattedDate(String format) {
	        Date date = new Date();
	        SimpleDateFormat ft = new SimpleDateFormat(format);
	        return ft.format(date);
	 }
}
