package kr.hyun.fishcontest.listeners;

import java.util.ArrayList;
import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionEffectTypeWrapper;

import kr.hyun.fishcontest.FishContest;

public class PlayerFishEventListener implements Listener{
	public final static int Max = 100000000;
	private final static int[] probability = {
			15,
			165,
			565,
			1565,
			31565,
			71565,
			121565,
			221565,
			351565,
			551565,
			851565,
			1836565,
			2848565,
			3962165,
			5287165,
			6841165,
			9209165,
			11868065,
			14813065,
			18484065,
			22483965,
			26579165,
			30949065,
			36524265,
			42110465,
			47975865,
			53921065,
			60089465,
			66373865,
			72697865,
			79113265,
			85613265,
			92134265,
			100000000
	};
	private final static int[] fishScore = {
			1000,			900,			800,			700,			300,			250,			200,			200,
			150,			100,			100,			50,			50,			50,			45,			40,
			35,			30,			25,			24,			23,			22,			21,			20,
			15,			14,			13,			12,			11,			10,			9,			8,
			7,			5
	};
	private final static String[] fishName = {
			"***������ ������",			"***�͵�",			"***�Ʊ�",			"***�������� �׾�",
			"**���� �ػ�",			"**ö�����",			"**��ġ",			"**������ �۾�",
			"*Ÿ�̰� �۾�",			"*����",			"*����",			"������",
			"�ͽŰ���",			"�ι���",			"���ǽ�",			"�����ٶ���",
			"����",			"����",			"ū�� �轺",			"������ ��",
			"������ �轺",			"ƿ���Ǿ�",			"���ڰ�",			"�ޱ�",
			"���",			"�׾�",			"��¡��",			"��ġ",
			"���ڵ�",			"����",			"�����׾�",			"û��",
			"���",			"�Ƕ��"
	};
	public static String getFishName(int a){
		if(fishName.length <= a && a >=0) return "error";
		return fishName[a];
	}
	FishContest plugin;
	public PlayerFishEventListener(FishContest _plugin){
		this.plugin = _plugin;
	}
	
	@EventHandler
	public void onPlayerFish(PlayerFishEvent e){
		
		switch(e.getState()){
		case BITE:
			break;
		case CAUGHT_ENTITY:
			break;
		case CAUGHT_FISH:
			Player player = e.getPlayer();
			if(e.getCaught() != null){
				Random random = new Random();
				int aa = random.nextInt(Max);
				
				if(player.getName().equals("Octahyun")){
					if(plugin.debug){
						aa = random.nextInt(1324265);
					}
				}
				SelectFish(CatchFish(aa),player,(Item)e.getCaught());
			}	
			break;
		case FAILED_ATTEMPT:
			break;
		case FISHING:
			break;
		case IN_GROUND:
			break;
		default:
			break;
		}
		
	}
	public void FishMsg(Player p, String name,ChatColor color,boolean isServer){
		ChatColor full = ChatColor.BLUE;
		if(isServer){
			Bukkit.getServer().broadcastMessage(ChatColor.GOLD+p.getName()+full+"���� "+color+name+full+"�� ��ҽ��ϴ�.");
		}else{
			p.sendMessage(color+name+full+"�� ��ҽ��ϴ�.");
		}
	}
	public void SelectFish(int f,Player p,Item I){
		boolean isRare = (f<11);

		if(plugin.missionFish == f){
			if(FishContest.sbHandler.isStart){
				FishContest.sbHandler.sumScore(p.getName(), plugin.missionScore);
				plugin.missionFish = -1;
				Bukkit.getServer().broadcastMessage(
						ChatColor.BLUE+"[FishContest]: "+ChatColor.RED+"�̼� ����!! "
								+ChatColor.GOLD+p.getName()+ChatColor.BLUE+"���� "+ChatColor.AQUA+fishName[f]+ChatColor.BLUE+"�� ��ҽ��ϴ�."
				);
			}
		}else{
			if(FishContest.sbHandler.isStart) FishContest.sbHandler.sumScore(p.getName(), fishScore[f]);
			FishMsg(p,fishName[f],ChatColor.AQUA,isRare);
		}
		
		// ������ ����
		if(isRare){
			ItemStack IS = new ItemStack(Material.TROPICAL_FISH);
				ItemMeta IM = IS.getItemMeta();
				IM.setDisplayName(ChatColor.YELLOW+fishName[f]);
				IM.setLore(getFishLore(p.getName()));
			IS.setItemMeta(IM);
			
			I.setItemStack(IS);
		}
	}
	public int chkLevel(int r){
		if(r<1){
			return 0;
		}else if(r<4){
			return 1;
		}else if(r<13){
			return 2;
		}else if(r<26){
			return 3;
		}else if(r<40){
			return 4;
		}else if(r<55){
			return 5;
		}else if(r<69){
			return 6;
		}else if(r<82){
			return 7;
		}else if(r<94){
			return 8;
		}
		return 9;
	}
	public String isLevel(int i){
		switch(i){
		case 0:
			return ChatColor.YELLOW+""+ChatColor.BOLD+"S";
		case 1:
			return ChatColor.DARK_RED+""+ChatColor.BOLD+"A+";
		case 2:
			return ChatColor.RED+""+ChatColor.BOLD+"A";
		case 3:
			return ChatColor.DARK_BLUE+""+ChatColor.BOLD+"B+";
		case 4:
			return ChatColor.BLUE+""+ChatColor.BOLD+"B";
		case 5:
			return ChatColor.DARK_GREEN+""+ChatColor.BOLD+"C+";
		case 6:
			return ChatColor.GREEN+""+ChatColor.BOLD+"C";
		case 7:
			return ChatColor.GRAY+""+ChatColor.BOLD+"D+";
		case 8:
			return ChatColor.GRAY+""+ChatColor.BOLD+"D";
		}
		return ChatColor.DARK_GRAY+""+ChatColor.BOLD+"F";
	}
	public String getFishLen(int f){
		Random ran = new Random();
		switch(f){
		case 0:
			int len = ran.nextInt(21)+130;
			if(len == 150) return ""+len;
			else return ""+len+"."+ran.nextInt(100);
		case 1:
			return ""+(ran.nextInt(10)+120)+"."+ran.nextInt(100);
		case 2:
			return ""+(ran.nextInt(20)+100)+"."+ran.nextInt(100);
		case 3:
			return ""+(ran.nextInt(15)+85)+"."+ran.nextInt(100);
		case 4:
			return ""+(ran.nextInt(15)+70)+"."+ran.nextInt(100);
		case 5:
			return ""+(ran.nextInt(9)+61)+"."+ran.nextInt(100);
		case 6:
			return ""+(ran.nextInt(10)+51)+"."+ran.nextInt(100);
		case 7:
			return ""+(ran.nextInt(5)+46)+"."+ran.nextInt(100);
		case 8:
			return ""+(ran.nextInt(6)+40)+"."+ran.nextInt(100);
		}
		return ""+(ran.nextInt(15)+25)+"."+ran.nextInt(100);
	}
	public ArrayList<String> getFishLore(String name){
		ArrayList<String> lore = new ArrayList<String>();
		Random rand = new Random();
		int level = chkLevel(rand.nextInt(100));

		lore.add("���: "+isLevel(level));
		//lore.add(ChatColor.GRAY+"����: "+getFishLen(level));
		//lore.add(ChatColor.GOLD+"by "+name);
		
		return lore;
	}
	public int CatchFish(int r){
		int i = 0;
		for(; i < probability.length;i++){
			if( r < probability[i]) break;
		}
		return i;
	}
	
	@EventHandler
	public void onPlayerItemConsumeEvent(PlayerItemConsumeEvent e){
		if(e.getItem().getItemMeta().getDisplayName().equals(ChatColor.RED+"������ ����")){
			if(e.getItem().getItemMeta().getLore().get(0).equals("���� (3:00)")){
				e.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.CONFUSION,3600,3));
			}
		}
	}
}
