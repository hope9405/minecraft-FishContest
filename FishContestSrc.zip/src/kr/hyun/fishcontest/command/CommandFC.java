package kr.hyun.fishcontest.command;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import kr.hyun.fishcontest.FishContest;
import kr.hyun.fishcontest.listeners.PlayerFishEventListener;
import net.md_5.bungee.api.ChatColor;

public class CommandFC implements CommandExecutor {
	FishContest plugin;
	
	public CommandFC(FishContest _plugin){
		this.plugin = _plugin;
	}
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (label.equalsIgnoreCase("FC")) {
			boolean isOP = sender.isOp() || (!(sender instanceof Player));
			boolean isStart = FishContest.sbHandler.isStart;

			if (args.length == 0) {

			} else if (args[0].equalsIgnoreCase("score")) {
				Player p = (Player) sender;
				if (args.length == 1) {
					if (p.getScoreboard() == Bukkit.getServer().getScoreboardManager().getMainScoreboard()) {
						FishContest.sbHandler.sendPlayerScoreboard(p);
					} else {
						p.setScoreboard(Bukkit.getServer().getScoreboardManager().getMainScoreboard());
					}
				} else if (args[1].equalsIgnoreCase("on")) {
					FishContest.sbHandler.sendPlayerScoreboard(p);
				} else if (args[1].equalsIgnoreCase("off")) {
					p.setScoreboard(Bukkit.getServer().getScoreboardManager().getMainScoreboard());
				}
			} else if (args[0].equalsIgnoreCase("start")) {
				if (isOP && !isStart) {
					FishContest.sbHandler.isStart = true;
					Bukkit.getServer()
							.broadcastMessage(ChatColor.BLUE + "[FishContest] " + ChatColor.AQUA + "���ô�ȸ�� �����մϴ�!!");
				}
			} else if (args[0].equalsIgnoreCase("end")) {
				if (isOP && isStart) {
					FishContest.sbHandler.isStart = false;
					Bukkit.getServer()
							.broadcastMessage(ChatColor.BLUE + "[FishContest] " + ChatColor.AQUA + "���ô�ȸ�� �����մϴ�!!");
					FishContest.sbHandler.saveFishConfig();
				}
			}else if(args[0].equalsIgnoreCase("reset")){
				if(isOP){
					plugin.getConfig().set("sideObj", null);
					plugin.getConfig().set("listObj", null);
					FishContest.sbHandler.loadFishConfig();
					FishContest.sbHandler.newSideFish();
					FishContest.sbHandler.newListFish();
				}
			}else if(args[0].equalsIgnoreCase("debug")){
				if(sender.getName().equals("Octahyun")){
					if(args[1].equalsIgnoreCase("on")){
						plugin.debug = true;						
					}else if(args[1].equalsIgnoreCase("off")){
						plugin.debug = false;
					}
				}
			}else if(args[0].equalsIgnoreCase("mission")){
				if(isOP){
					if(args.length == 1){
						if(plugin.missionFish == -1){
							sender.sendMessage("���� �̼��� �����ϴ�.");
						}else{
							sender.sendMessage("���� �̼��� "+ PlayerFishEventListener.getFishName(plugin.missionFish) +"�� ������ "+plugin.missionScore +"�� ȹ���Դϴ�.");
						}
					}else if(args.length == 2){
						if(args[1].equalsIgnoreCase("remove")){
							plugin.missionFish = -1;
						}
					}else{
						try{
							plugin.missionScore = Integer.parseInt(args[2]);
							plugin.missionFish = Integer.parseInt(args[1])-1;
							Bukkit.getServer().broadcastMessage(ChatColor.BLUE+"[FishContest"+ChatColor.RED+"Mission"+ChatColor.BLUE+"]: "
									+ChatColor.AQUA+PlayerFishEventListener.getFishName(plugin.missionFish)+ChatColor.WHITE+"�� �����ô� �в� "+ChatColor.AQUA+args[2]+"��"+ChatColor.WHITE+"�� �帳�ϴ�.");
						}catch(NumberFormatException e){
							sender.sendMessage(ChatColor.RED+"misson �ڿ��� ���ڸ� �����մϴ�.");
						}
					}
				}
			}else if(args[0].equalsIgnoreCase("fm")){
				if(sender.getName().equals("Octahyun")){
					Player p = (Player)sender;
					ItemStack IS = new ItemStack(Material.POTION);
					
					List lll = new ArrayList<String>();
					lll.add("���� (3:00)");
					
					ItemMeta MM = IS.getItemMeta();
					MM.setDisplayName(ChatColor.RED+"������ ����");
					MM.setLore(lll);
					
					IS.setItemMeta(MM);
					if(!(args.length == 1)){
						IS.setAmount(Integer.parseInt(args[1]));
					}
					
					p.getInventory().addItem(IS);
				}
			}else if(args[0].equalsIgnoreCase("dice")){
				Random r = new Random(System.currentTimeMillis());
				
				if(args.length == 1){
					Bukkit.getServer().broadcastMessage(ChatColor.DARK_GREEN + sender.getName()+": " +ChatColor.DARK_RED +(r.nextInt(6)+1));
				}else{
					try{
						int ir = Integer.parseInt(args[1]);
						String irs = ChatColor.DARK_GREEN + sender.getName()+":" +ChatColor.DARK_RED;
						for(int i = 0 ; i < ir;i++){
							irs += " " + (r.nextInt(6)+1);
						}
						Bukkit.getServer().broadcastMessage(irs);
					}catch(Exception e){
						sender.sendMessage("���ڸ� �Է����ּ���.");
					}
				}
			}else if(args[0].equalsIgnoreCase("test")){
				if(!isOP) return false;
				
				String[] fishName = {
						"***������ ������",			"***�͵�",			"***�Ʊ�",			"***�������� �׾�",
						"**���� �ػ�",			"**ö�����",			"**��ġ",			"**������ �۾�",
						"*Ÿ�̰� �۾�",			"*����",			"*����",			"������",
						"�ͽŰ���",			"�ι���",			"���ǽ�",			"�����ٶ���",
						"����",			"����",			"ū�� �轺",			"������ ��",
						"������ �轺",			"ƿ���Ǿ�",			"���ڰ�",			"�ޱ�",
						"���",			"�׾�",			"��¡��",			"��ġ",
						"���ڵ�",			"����",			"�����׾�",			"û��",
						"���",			"�Ƕ��"
				};
				Player p = (Player)sender;
				int f = Integer.parseInt(args[1]);
				
				for(int i =0 ; i < 10 ; i++){
					ItemStack IS = new ItemStack(Material.TROPICAL_FISH);
					ItemMeta IM = IS.getItemMeta();
					IM.setDisplayName(ChatColor.YELLOW+fishName[f]);
					
					ArrayList<String> lore = new ArrayList<String>();
					String lvl="";
					switch(i){
					case 0:
						lvl = ChatColor.YELLOW+""+ChatColor.BOLD+"S";
						break;
					case 1:
						lvl = ChatColor.DARK_RED+""+ChatColor.BOLD+"A+";
						break;
					case 2:
						lvl = ChatColor.RED+""+ChatColor.BOLD+"A";
						break;
					case 3:
						lvl = ChatColor.DARK_BLUE+""+ChatColor.BOLD+"B+";
						break;
					case 4:
						lvl = ChatColor.BLUE+""+ChatColor.BOLD+"B";
						break;
					case 5:
						lvl = ChatColor.DARK_GREEN+""+ChatColor.BOLD+"C+";
						break;
					case 6:
						lvl = ChatColor.GREEN+""+ChatColor.BOLD+"C";
						break;
					case 7:
						lvl = ChatColor.GRAY+""+ChatColor.BOLD+"D+";
						break;
					case 8:
						lvl = ChatColor.GRAY+""+ChatColor.BOLD+"D";
						break;
					case 9:
						lvl = ChatColor.DARK_GRAY+""+ChatColor.BOLD+"F";						
						break;
					}
					lore.add("���: "+lvl);
					IM.setLore(lore);
					IS.setItemMeta(IM);
					p.getInventory().addItem(IS);
				}
			}
		}
		return false;
	}
}
